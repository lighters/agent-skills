from export import export_csv

def test_export():
    assert export_csv([]).startswith(b"name,email")
