# 需求与实现对照审查

## 结论

本报告为静态源码与交付材料核对，未执行代码或测试。确认范围仅为 R1–R4。R1 的 CSV 编码、表头和输入行输出在源码中已实现；R2 的公式保护在可访问的导出链路中缺失；R3 的真实目录服务接入缺失，实际实现返回内嵌 Demo 数据。R4 拆为生产部署与客户验收，两项均无法验证。历史 Demo 成功描述不能证明当前版本运行通过、生产部署或客户验收。

按独立行为拆分为 5 行：已实现 1、部分实现 0、缺失 2、无法验证 2。此为静态实现判断分布，不是项目完成率或验收通过率；本次运行验证为 0 项，生产及验收均未取得证明。

## 审查范围与基线

- 审查日期：2026-09-29。
- 权威需求：requirements.md，v1，标题注明本次练习已确认；文档未提供批准日期，[requirements.md:1](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/requirements.md:1)、[requirements.md:8](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/requirements.md:8)。
- 代码范围：`/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/source`，目录内仅 export.py，完整阅读第 1–19 行；文件自述为合成评估样例，不能代表生产实现。
- Git revision／工作区变更：输入目录不属于 Git 仓库，无法取得 revision、Git 状态或相对基线变更。本报告覆盖当前提供文件的实际内容，不声称其等于某个提交。
- 交付材料：delivery-notes.md，历史记录日期 2025-01-10、版本 unknown、环境 demo。
- 排除范围：未批准 v2 路线图中的移除公式保护和新增 XLSX，依据确认需求第 8 行及交付材料第 7–9 行。未将 XLSX 缺少列为交付缺口。
- 已检查：三份输入文件全部内容、源码目录文件范围、导出函数及其调用链、交付声明的版本与环境。未使用外部服务，未修改输入，未执行样例代码或测试。

## 需求—证据矩阵

| ID | 需求及来源定位 | 明确条件／建议条件 | 实现判断 | 源码检查、证据 ID 与关键解释 | 运行验证 | 部署状态 | 验收状态 | 缺口、下一步及通过条件 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| R1 | UTF-8 CSV 字节、name,email 表头、所供用户行；[requirements.md:3](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/requirements.md:3) | 明确条件：返回 UTF-8 bytes；列按 name,email 顺序；输出传入 users 中每行 | 已实现（仅源码检查） | E1、E2：csv.writer 写固定表头及 users 的 name/email，最后 encode('utf-8')；三项均有直接代码证据 | 未运行；历史 Demo 描述无当前版本与输入对应关系 | 无证据 | 无证据 | 补针对当前版本的空输入、多行、中文及 CSV 特殊字符运行结果；通过条件为字节可 UTF-8 解码、CSV 解析后表头及行值顺序正确。这是建议验证样例，不是新增范围 |
| R2 | 以 =、+、-、@ 开始的单元格前加单引号；[requirements.md:4](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/requirements.md:4) | 明确条件：四种前缀逐格保护 | 缺失（所提供源码范围） | E1、E2、E3：完整检查 export_directory → directory_users → export_csv；值直接交给 writer，未做前缀检查或加单引号。CSV 的分隔／引号转义不等于公式保护 | 未运行；源码推断，不称已复现 | 无证据 | 无证据 | 在输出单元格前实现保护；分别覆盖两个字段的四种首字符，CSV 解析后应以单引号加原值开始，普通文本不变 |
| R3 | 导出用户来自真实目录服务，而非内嵌演示行；[requirements.md:5](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/requirements.md:5) | 明确条件：实际导出链路获取真实目录用户 | 缺失（所提供源码范围） | E3：export_directory 调用 directory_users，后者固定返回 Demo 与 demo@example.invalid；全文件导入仅 csv/io，无其他数据获取分支或真实目录调用 | 未运行真实集成；Demo 数据不能证明真实服务 | 无证据 | 无证据 | 用真实目录客户端接入该导出入口；需在授权环境记录接口、时间、版本、输入类别和观察结果，并证明导出内容来自服务且非静态替身 |
| R4-D | 必须部署到生产；[requirements.md:6](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/requirements.md:6) | 明确条件：生产部署完成（R4 拆项） | 无法验证 | E4：只有版本不明的 Demo 说明，无生产回执；提供源码本身也不能证明部署 | 未运行生产路径 | 无法验证；未提供生产环境、版本查询或部署回执 | 与 R4-A 分开判断 | 补生产环境及部署版本的可追踪回执／版本查询；通过条件为目标版本与受审实现可关联，且明确部署到生产。不得把缺回执断言为未部署 |
| R4-A | 必须由客户验收；[requirements.md:6](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/requirements.md:6) | 明确条件：客户接受导出功能（R4 拆项） | 无法验证 | E4：未附客户验收记录；演示成功与客户接受不同 | 运行结果不能替代验收 | 无法验证 | 无法验证；未提供签署人、范围、版本与日期 | 补客户认可的验收记录及适用需求／版本／日期；通过条件为客户明确接受对应交付范围。不得把缺记录断言为客户拒绝或未验收 |

## 证据索引

| ID | 类型 | 文件＋行号 | 版本、环境与时间 | 支持的主张 | 局限 |
| --- | --- | --- | --- | --- | --- |
| E1 | 已确认需求 | [requirements.md:1](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/requirements.md:1)；第 3–8 行 | v1；日期未提供；本练习确认范围 | R1–R4 权威基线，v2 未批准 | 不证明已实现 |
| E2 | 当前源码 | [source/export.py:6](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/source/export.py:6)；第 6–11 行 | 当前提供样例；无 Git revision；审查于 2026-09-29 | UTF-8 CSV 输出与输入行映射；直接写单元格，无公式防护 | 未执行；不证明线上行为；仅针对所供有效 users 结构 |
| E3 | 当前源码与调用链 | [source/export.py:1](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/source/export.py:1)；第 1–19 行，重点第 14–19 行 | 合成评估样例，明确非生产实现 | 内嵌 Demo 数据；导出入口实际调用此数据源 | 不否定未提供的其他系统可能另有真实接入；不能推广为生产系统全局结论 |
| E4 | 历史交付说明 | [delivery-notes.md:1](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/delivery-notes.md:1)；第 1–5 行 | 2025-01-10；版本 unknown；demo | 材料声称曾成功演示，并明确无命令、日志、部署回执、验收记录附件 | 不是可复核执行输出；不能映射当前代码，不能证明生产及验收 |
| E5 | 未批准路线图 | [delivery-notes.md:7](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/baseline/input/delivery-notes.md:7)；第 7–9 行 | draft v2；批准日期不存在于材料 | 建议移除公式防护并增加 XLSX | 不修改已确认 v1 范围，不作为缺口判定依据 |

## 来源冲突与待确认

| 冲突／问题 | 来源双方 | 影响的需求 | 当前处理 | 需确认的具体问题 |
| --- | --- | --- | --- | --- |
| 公式保护要求与路线图移除建议相反 | E1 v1 第 4 行 vs E5 draft v2 第 9 行 | R2 | 用户基线明确为已确认 v1；保留公式保护要求，不能用草案解释代码缺失 | 无需为本审查暂停；如未来变更，需正式批准记录 |
| 历史成功演示与当前样例的能力边界不同 | E4 Demo 声明 vs E2/E3 当前样例 | R1–R4 | 不是同版本同环境实测矛盾；声明不升级为真实集成、生产或验收证据 | 演示对应哪个版本、何种数据源、覆盖哪些行为？ |
| 生产与验收资料缺口 | E1 R4 要求 vs E4 无附件说明 | R4-D/R4-A | 标为无法验证，不标缺失或已完成 | 生产目标、部署版本和客户验收记录由谁提供？ |

## 优先行动

1. **补公式防护（R2）**：按源码推断，传入 name='=1+1' 等值会保留公式首字符；预期应在单元格值前加单引号。修复后逐一验证四种首字符、两个字段与普通文本。负责人／期限：待指定。
2. **补真实目录接入及证据（R3）**：替换导出调用链内固定 Demo 返回，取得授权环境真实接口结果和导出关联证据；通过条件是同版本实际调用真实目录且输出来源可追踪。负责人／期限：待指定。
3. **补当前版本运行证明（R1、R2、R3）**：记录版本、输入、环境、命令和结果，区分模拟依赖与真实连接。通过条件为逐项行为符合确认需求，不能以测试文件存在替代成功执行。负责人／期限：待指定。
4. **补生产与客户记录（R4-D、R4-A）**：分别核对部署回执和明确验收记录；将其关联至同一交付范围与版本。在此之前不报告生产可用或客户已验收。负责人／期限：待指定。

## 验证边界

仅对提供的三份文件作静态分析；所有运行结果均未验证，未执行样例或测试、未访问目录服务或生产、未实施任何修复或部署。R2/R3 的“缺失”限于完整可访问样例调用链的直接反证，不是全局关键词无命中的推断。R4 的资料缺少不等于实际行为没有发生。需求来源未规定详细客户验收流程，报告列出的记录字段是补足证明的建议，不是未经批准的新需求。
