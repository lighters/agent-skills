# 需求与实现对照审查

## 结论

提供的源码支持 R1 已实现（仅源码检查），同时直接显示 R2 公式保护与 R3 真实目录取数在该源码内缺失。old-run.log 是 2024-12-01、legacy-0.8、staging 的历史成功记录，明确来自不同版本，不能证明当前真实集成，更不能证明生产部署或客户验收。生产部署和客户验收均无法验证。

## 审查范围与基线

- 审查日期：2026-09-29；确认基线 requirements.md v1，第 3–6 行，文件日期未提供。
- 只读审查 `/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input` 全部四份材料：需求、交付说明、source/export.py、old-run.log。
- 当前源码注明合成材料，非生产实现；Git revision、源码日期、工作区变更状态未提供。不可把历史日志版本用作当前源码版本。
- 检查完整源码调用链和日志元信息，未运行代码或测试、未访问外部系统。
- 未批准 v2 草案不改变 R2，不将 XLSX 纳入确认范围。

## 需求—证据矩阵

| ID | 需求及来源定位 | 明确条件／建议条件 | 实现判断 | 证据 ID 与关键解释 | 运行验证 | 部署状态 | 验收状态 | 缺口、下一步及通过条件 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| R1 | [requirements.md:3](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/requirements.md:3) | UTF-8 CSV 字节；name,email 表头；传入用户行 | 已实现（仅源码检查） | E2 第 6–11 行逐项覆盖 | 当前未运行；E3 非 CSV 当前验证 | 未提供 | 未提供 | 对指定版本以中文、多行及 CSV 特殊字符输入执行，解码/解析核对表头和全部用户行 |
| R2 | [requirements.md:4](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/requirements.md:4) | =、+、-、@ 前缀单元格添加单引号 | 缺失（限提供源码） | E2 第 10 行直接写字段，完整调用链没有保护处理 | 未运行；源码推断 | 未提供 | 未提供 | 对两个字段实施保护；四种前缀 CSV 解析后均有前置单引号，普通值保留 |
| R3 | [requirements.md:5](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/requirements.md:5) | 实际从真实目录服务取用户，不用嵌入 Demo 行 | 缺失（限提供源码） | E2 第 14–19 行固定 Demo 列表；E3 不能跨版本证明实现 | 当前未验证；仅旧版本 staging 成功记录 | 未提供 | 未提供 | 接通真实目录客户端，并补同版本、明确环境/时间/输入类别/响应结果的真实请求证据 |
| R4a | [requirements.md:6](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/requirements.md:6) | 部署生产 | 无法验证 | E3 为 staging；E4 无部署回执 | 未提供生产业务路径结果 | 无法验证 | 不适用本子项 | 补生产回执或版本查询并对应受审版本 |
| R4b | [requirements.md:6](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/requirements.md:6) | 客户验收 | 无法验证 | E4 无验收记录；E3 PASS 是集成日志，非验收 | 未提供当前结果 | 未提供 | 无法验证 | 补客户签署的范围、版本、日期和验收结论 |

## 证据索引

| ID | 类型 | 文件＋行号 | 版本、环境与时间 | 支持的主张 | 局限 |
| --- | --- | --- | --- | --- | --- |
| E1 | 确认需求 | [requirements.md:1](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/requirements.md:1)；3–8 行 | v1；日期未提供 | 仅 R1–R4 为确认范围 | 不能证明完成 |
| E2 | 提供的当前源码 | [source/export.py:1](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/source/export.py:1)；6–19 行 | 合成；revision/日期未提供 | CSV 写入路径、无保护转换、固定 Demo 数据源 | 未执行；不能代表未提供的生产系统 |
| E3 | 历史执行日志 | [old-run.log:1](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/old-run.log:1) | legacy-0.8；staging；2024-12-01 | 该历史记录报告 directory integration PASS，返回 20 个用户 | 明确不同版本；无请求/来源明细，不能独立证明真实连接、当前实现或生产部署 |
| E4 | 历史交付说明 | [delivery-notes.md:3](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/delivery-notes.md:3)；3–5 行 | 版本未知；demo；2025-01-10 | 有成功演示声明，说明中未附验证/部署/验收凭据 | 与 E3 不同日期、环境，不能自动关联或覆盖当前证据 |
| E5 | 未批准路线图 | [delivery-notes.md:7](/var/folders/2m/jj1m_pw93g56yqgx0xj6yvzm0000gn/T/scope-evidence-eval-20260929-a65nas5d/old-log/input/delivery-notes.md:7)；7–9 行 | draft v2；日期未提供 | 取消保护、增加 XLSX 的提议 | 不改变基线 |

## 来源冲突与待确认

| 问题 | 来源双方 | 影响 | 当前处理 | 需确认的具体问题 |
| --- | --- | --- | --- | --- |
| 历史集成 PASS 与当前固定 Demo 数据 | E3 / E2 | R3 | 记录版本/环境差异，不用旧成功覆盖当前缺口；也不反推旧日志造假 | 当前源码版本及同版本真实集成证据 |
| 交付说明称未附日志，但材料另有旧日志 | E4 / E3 | 运行证据 | 旧日志保留独立来源；日期和环境不同，不视为该演示的执行附件 | 是否存在与演示或当前版本关联的可追溯结果 |
| 取消保护的草案与确认要求 | E5 / E1 | R2 | 使用确认 v1；XLSX 不纳入 | 本次无须追加决策；未来变更须批准记录 |

## 优先行动与验证边界

优先补 R2 和 R3；随后提供同版本功能/真实集成结果，再核对生产部署与客户验收。负责人、期限均待指定。缺失结论来自读取完整可访问实现：export_directory 调用 directory_users 的固定列表，再由 export_csv 无转换写出字段；不是由关键词未命中推定。当前没有任何运行复现，不宣称测试通过、生产可用或已验收。历史结果仅限其记录的版本和环境，不能外推。未计算完成率。
